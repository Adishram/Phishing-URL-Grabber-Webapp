"use client"

import { useState, useEffect } from "react"
import { Shield, Search, History, Settings, BarChart3, AlertTriangle, CheckCircle, Clock, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ScanResult {
  url: string
  prediction: "Phishing" | "Legitimate"
  confidence: number
  phishing_probability: number
  legitimate_probability: number
  timestamp: string
}

interface Stats {
  urlsScannedToday: number
  totalScans: number
  phishingDetected: number
  safeUrls: number
}

export default function PhishGuardDashboard() {
  const [currentUrl, setCurrentUrl] = useState("")
  const [isScanning, setIsScanning] = useState(false)
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [scanHistory, setScanHistory] = useState<ScanResult[]>([])
  const [stats, setStats] = useState<Stats>({
    urlsScannedToday: 0,
    totalScans: 0,
    phishingDetected: 0,
    safeUrls: 0,
  })

  // Load scan history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem("phishguard-history")
    if (savedHistory) {
      const history = JSON.parse(savedHistory)
      setScanHistory(history)
      updateStats(history)
    }
  }, [])

  const updateStats = (history: ScanResult[]) => {
    const today = new Date().toDateString()
    const todayScans = history.filter((scan) => new Date(scan.timestamp).toDateString() === today)

    setStats({
      urlsScannedToday: todayScans.length,
      totalScans: history.length,
      phishingDetected: history.filter((scan) => scan.prediction === "Phishing").length,
      safeUrls: history.filter((scan) => scan.prediction === "Legitimate").length,
    })
  }

  const scanUrl = async (url: string) => {
    if (!url) return

    setIsScanning(true)
    try {
      const response = await fetch("http://127.0.0.1:5000/api/check-url", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
      })

      if (response.ok) {
        const result = await response.json()
        setScanResult(result)

        // Add to history
        const newHistory = [result, ...scanHistory].slice(0, 100) // Keep last 100 scans
        setScanHistory(newHistory)
        localStorage.setItem("phishguard-history", JSON.stringify(newHistory))
        updateStats(newHistory)
      } else {
        throw new Error("Failed to scan URL")
      }
    } catch (error) {
      console.error("Error scanning URL:", error)
      // Show error state
    } finally {
      setIsScanning(false)
    }
  }

  const scanCurrentPage = () => {
    if (typeof window !== "undefined") {
      const currentPageUrl = window.location.href
      setCurrentUrl(currentPageUrl)
      scanUrl(currentPageUrl)
    }
  }

  const handleManualScan = () => {
    if (currentUrl.trim()) {
      scanUrl(currentUrl.trim())
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="glass-card border-b border-border/50 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-primary/20">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">PhishGuard</h1>
                <p className="text-sm text-muted-foreground">Advanced Phishing Detection</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="glass-card">
                <Zap className="h-3 w-3 mr-1" />
                AI Powered
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="scanner" className="space-y-8">
          <TabsList className="glass-card p-1 h-auto">
            <TabsTrigger value="scanner" className="glass-button data-[state=active]:bg-primary/80">
              <Search className="h-4 w-4 mr-2" />
              Scanner
            </TabsTrigger>
            <TabsTrigger value="history" className="glass-button data-[state=active]:bg-primary/80">
              <History className="h-4 w-4 mr-2" />
              History
            </TabsTrigger>
            <TabsTrigger value="stats" className="glass-button data-[state=active]:bg-primary/80">
              <BarChart3 className="h-4 w-4 mr-2" />
              Statistics
            </TabsTrigger>
            <TabsTrigger value="settings" className="glass-button data-[state=active]:bg-primary/80">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scanner" className="space-y-6">
            {/* URL Scanner Section */}
            <Card className="glass-card border-border/50">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-foreground">URL Scanner</CardTitle>
                <CardDescription className="text-muted-foreground">
                  Enter a URL to check if it's safe or potentially malicious
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-3">
                  <Input
                    placeholder="Enter URL to scan (e.g., https://example.com)"
                    value={currentUrl}
                    onChange={(e) => setCurrentUrl(e.target.value)}
                    className="glass-input text-foreground placeholder:text-muted-foreground"
                    onKeyPress={(e) => e.key === "Enter" && handleManualScan()}
                  />
                  <Button
                    onClick={handleManualScan}
                    disabled={isScanning || !currentUrl.trim()}
                    className="glass-button px-6"
                  >
                    {isScanning ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    ) : (
                      <Search className="h-4 w-4" />
                    )}
                  </Button>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={scanCurrentPage}
                    variant="secondary"
                    className="glass-button bg-secondary/80 hover:bg-secondary flex-1"
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Scan Current Page
                  </Button>
                </div>

                {/* Scan Result */}
                {scanResult && (
                  <Card className="glass-card border-border/50 mt-6">
                    <CardContent className="pt-6">
                      <div className="flex items-start gap-4">
                        <div
                          className={`p-3 rounded-full ${
                            scanResult.prediction === "Legitimate"
                              ? "bg-green-500/20 text-green-400"
                              : "bg-red-500/20 text-red-400"
                          }`}
                        >
                          {scanResult.prediction === "Legitimate" ? (
                            <CheckCircle className="h-6 w-6" />
                          ) : (
                            <AlertTriangle className="h-6 w-6" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg text-foreground">
                            {scanResult.prediction === "Legitimate" ? "Safe URL" : "Potential Threat Detected"}
                          </h3>
                          <p className="text-muted-foreground text-sm mb-3">{scanResult.url}</p>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Confidence:</span>
                              <span className="ml-2 font-medium text-foreground">
                                {(scanResult.confidence * 100).toFixed(1)}%
                              </span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Risk Level:</span>
                              <span
                                className={`ml-2 font-medium ${
                                  scanResult.phishing_probability > 0.7
                                    ? "text-red-400"
                                    : scanResult.phishing_probability > 0.3
                                      ? "text-yellow-400"
                                      : "text-green-400"
                                }`}
                              >
                                {scanResult.phishing_probability > 0.7
                                  ? "High"
                                  : scanResult.phishing_probability > 0.3
                                    ? "Medium"
                                    : "Low"}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card className="glass-card border-border/50">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-foreground">Detection History</CardTitle>
                <CardDescription className="text-muted-foreground">
                  View your recent URL scans and results
                </CardDescription>
              </CardHeader>
              <CardContent>
                {scanHistory.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No scans yet. Start by scanning a URL above.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {scanHistory.slice(0, 10).map((scan, index) => (
                      <div key={index} className="glass-card p-4 border-border/30">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div
                              className={`p-2 rounded-full ${
                                scan.prediction === "Legitimate"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              {scan.prediction === "Legitimate" ? (
                                <CheckCircle className="h-4 w-4" />
                              ) : (
                                <AlertTriangle className="h-4 w-4" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium text-foreground text-sm">
                                {scan.url.length > 50 ? `${scan.url.substring(0, 50)}...` : scan.url}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(scan.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <Badge variant={scan.prediction === "Legitimate" ? "secondary" : "destructive"}>
                            {scan.prediction}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="glass-card border-border/50">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-blue-500/20">
                      <Clock className="h-5 w-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{stats.urlsScannedToday}</p>
                      <p className="text-sm text-muted-foreground">URLs Scanned Today</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border/50">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-green-500/20">
                      <CheckCircle className="h-5 w-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{stats.safeUrls}</p>
                      <p className="text-sm text-muted-foreground">Safe URLs</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border/50">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-red-500/20">
                      <AlertTriangle className="h-5 w-5 text-red-400" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{stats.phishingDetected}</p>
                      <p className="text-sm text-muted-foreground">Threats Detected</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border/50">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-purple-500/20">
                      <BarChart3 className="h-5 w-5 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{stats.totalScans}</p>
                      <p className="text-sm text-muted-foreground">Total Scans</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="glass-card border-border/50">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-foreground">Settings</CardTitle>
                <CardDescription className="text-muted-foreground">
                  Configure your PhishGuard preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">Auto-scan on page load</h4>
                      <p className="text-sm text-muted-foreground">Automatically scan URLs when pages load</p>
                    </div>
                    <Button variant="outline" size="sm" className="glass-button bg-transparent">
                      Enable
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">Real-time protection</h4>
                      <p className="text-sm text-muted-foreground">Block access to detected phishing sites</p>
                    </div>
                    <Button variant="outline" size="sm" className="glass-button bg-transparent">
                      Configure
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-foreground">Clear scan history</h4>
                      <p className="text-sm text-muted-foreground">Remove all stored scan results</p>
                    </div>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        localStorage.removeItem("phishguard-history")
                        setScanHistory([])
                        setStats({ urlsScannedToday: 0, totalScans: 0, phishingDetected: 0, safeUrls: 0 })
                      }}
                    >
                      Clear
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
