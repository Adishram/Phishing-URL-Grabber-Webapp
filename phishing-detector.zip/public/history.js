// PhishGuard History Page Script
class PhishGuardHistory {
  constructor() {
    this.chrome = window.chrome
    this.history = []
    this.filteredHistory = []
    this.currentPage = 1
    this.itemsPerPage = 20
    this.init()
  }

  async init() {
    await this.loadHistory()
    this.updateStats()
    this.bindEvents()
    this.renderHistory()
  }

  async loadHistory() {
    try {
      const result = await this.getStorageData("scanHistory")
      this.history = result || []
      this.filteredHistory = [...this.history]
    } catch (error) {
      console.error("Error loading history:", error)
      this.history = []
      this.filteredHistory = []
    }
  }

  updateStats() {
    const today = new Date().toDateString()
    const todayScans = this.history.filter((scan) => new Date(scan.timestamp).toDateString() === today).length

    const safeUrls = this.history.filter((scan) => scan.prediction === "Legitimate").length
    const threatsDetected = this.history.filter((scan) => scan.prediction === "Phishing").length

    document.getElementById("totalScans").textContent = this.history.length
    document.getElementById("safeUrls").textContent = safeUrls
    document.getElementById("threatsDetected").textContent = threatsDetected
    document.getElementById("todayScans").textContent = todayScans
  }

  bindEvents() {
    // Filter events
    document.getElementById("searchInput").addEventListener("input", () => this.applyFilters())
    document.getElementById("resultFilter").addEventListener("change", () => this.applyFilters())
    document.getElementById("dateFilter").addEventListener("change", () => this.applyFilters())
    document.getElementById("sortFilter").addEventListener("change", () => this.applyFilters())

    // Action events
    document.getElementById("exportBtn").addEventListener("click", () => this.exportData())
    document.getElementById("clearBtn").addEventListener("click", () => this.clearHistory())

    // Pagination events
    document.getElementById("prevBtn").addEventListener("click", () => this.previousPage())
    document.getElementById("nextBtn").addEventListener("click", () => this.nextPage())
  }

  applyFilters() {
    let filtered = [...this.history]

    // Search filter
    const searchTerm = document.getElementById("searchInput").value.toLowerCase()
    if (searchTerm) {
      filtered = filtered.filter((item) => item.url.toLowerCase().includes(searchTerm))
    }

    // Result filter
    const resultFilter = document.getElementById("resultFilter").value
    if (resultFilter !== "all") {
      filtered = filtered.filter((item) => item.prediction === resultFilter)
    }

    // Date filter
    const dateFilter = document.getElementById("dateFilter").value
    if (dateFilter !== "all") {
      const now = new Date()
      const filterDate = new Date()

      switch (dateFilter) {
        case "today":
          filterDate.setHours(0, 0, 0, 0)
          break
        case "week":
          filterDate.setDate(now.getDate() - 7)
          break
        case "month":
          filterDate.setMonth(now.getMonth() - 1)
          break
      }

      filtered = filtered.filter((item) => new Date(item.timestamp) >= filterDate)
    }

    // Sort filter
    const sortFilter = document.getElementById("sortFilter").value
    switch (sortFilter) {
      case "newest":
        filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        break
      case "oldest":
        filtered.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
        break
      case "confidence":
        filtered.sort((a, b) => (b.confidence || 0) - (a.confidence || 0))
        break
      case "risk":
        filtered.sort((a, b) => (b.phishing_probability || 0) - (a.phishing_probability || 0))
        break
    }

    this.filteredHistory = filtered
    this.currentPage = 1
    this.renderHistory()
  }

  renderHistory() {
    const historyList = document.getElementById("historyList")
    const emptyState = document.getElementById("emptyState")

    if (this.filteredHistory.length === 0) {
      emptyState.classList.remove("hidden")
      historyList.innerHTML = ""
      historyList.appendChild(emptyState)
      this.updatePagination()
      return
    }

    emptyState.classList.add("hidden")

    const startIndex = (this.currentPage - 1) * this.itemsPerPage
    const endIndex = startIndex + this.itemsPerPage
    const pageItems = this.filteredHistory.slice(startIndex, endIndex)

    historyList.innerHTML = ""

    pageItems.forEach((item) => {
      const historyItem = this.createHistoryItem(item)
      historyList.appendChild(historyItem)
    })

    this.updatePagination()
  }

  createHistoryItem(item) {
    const div = document.createElement("div")
    div.className = "history-item"

    const statusClass = this.getStatusClass(item.prediction)
    const statusIcon = this.getStatusIcon(item.prediction)
    const riskLevel = this.getRiskLevel(item.phishing_probability || 0)
    const confidence = ((item.confidence || 0) * 100).toFixed(1)

    div.innerHTML = `
            <div class="history-header">
                <div class="history-status">
                    <div class="status-icon ${statusClass}">
                        ${statusIcon}
                    </div>
                    <div>
                        <div class="status-text">${item.prediction || "Unknown"}</div>
                        <div class="history-url">${this.truncateUrl(item.url)}</div>
                    </div>
                </div>
                <div class="history-meta">
                    <span>📅 ${this.formatDate(item.timestamp)}</span>
                    <span>⏰ ${this.formatTime(item.timestamp)}</span>
                    ${item.fallback ? "<span>🔄 Fallback</span>" : ""}
                </div>
            </div>
            <div class="history-details">
                <div class="detail-item">
                    <span class="detail-label">Confidence:</span>
                    <span class="detail-value">${confidence}%</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Risk Level:</span>
                    <span class="detail-value" style="color: ${riskLevel.color}">${riskLevel.text}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Phishing Score:</span>
                    <span class="detail-value">${((item.phishing_probability || 0) * 100).toFixed(1)}%</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Method:</span>
                    <span class="detail-value">${item.fallback ? "Heuristics" : "AI Model"}</span>
                </div>
            </div>
        `

    return div
  }

  getStatusClass(prediction) {
    switch (prediction) {
      case "Legitimate":
        return "safe"
      case "Phishing":
        return "danger"
      default:
        return "unknown"
    }
  }

  getStatusIcon(prediction) {
    switch (prediction) {
      case "Legitimate":
        return "✅"
      case "Phishing":
        return "⚠️"
      default:
        return "❓"
    }
  }

  getRiskLevel(score) {
    if (score > 0.7) {
      return { text: "High", color: "#ef4444" }
    } else if (score > 0.3) {
      return { text: "Medium", color: "#f59e0b" }
    } else {
      return { text: "Low", color: "#22c55e" }
    }
  }

  truncateUrl(url) {
    return url.length > 80 ? url.substring(0, 77) + "..." : url
  }

  formatDate(timestamp) {
    return new Date(timestamp).toLocaleDateString()
  }

  formatTime(timestamp) {
    return new Date(timestamp).toLocaleTimeString()
  }

  updatePagination() {
    const totalPages = Math.ceil(this.filteredHistory.length / this.itemsPerPage)
    const prevBtn = document.getElementById("prevBtn")
    const nextBtn = document.getElementById("nextBtn")
    const paginationInfo = document.getElementById("paginationInfo")

    prevBtn.disabled = this.currentPage <= 1
    nextBtn.disabled = this.currentPage >= totalPages

    paginationInfo.textContent = `Page ${this.currentPage} of ${totalPages}`

    if (totalPages <= 1) {
      document.getElementById("pagination").style.display = "none"
    } else {
      document.getElementById("pagination").style.display = "flex"
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--
      this.renderHistory()
    }
  }

  nextPage() {
    const totalPages = Math.ceil(this.filteredHistory.length / this.itemsPerPage)
    if (this.currentPage < totalPages) {
      this.currentPage++
      this.renderHistory()
    }
  }

  async exportData() {
    try {
      const exportData = {
        exportDate: new Date().toISOString(),
        totalScans: this.history.length,
        history: this.history,
        summary: {
          safeUrls: this.history.filter((scan) => scan.prediction === "Legitimate").length,
          threatsDetected: this.history.filter((scan) => scan.prediction === "Phishing").length,
          unknownResults: this.history.filter((scan) => scan.prediction === "Unknown").length,
        },
      }

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: "application/json",
      })

      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `phishguard-history-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      this.showNotification("Export successful", "Your scan history has been exported.")
    } catch (error) {
      console.error("Export error:", error)
      this.showNotification("Export failed", "Failed to export scan history.")
    }
  }

  async clearHistory() {
    if (!confirm("Are you sure you want to clear all scan history? This action cannot be undone.")) {
      return
    }

    try {
      await this.chrome.storage.local.set({ scanHistory: [] })
      this.history = []
      this.filteredHistory = []
      this.updateStats()
      this.renderHistory()
      this.showNotification("History cleared", "All scan history has been removed.")
    } catch (error) {
      console.error("Clear history error:", error)
      this.showNotification("Clear failed", "Failed to clear scan history.")
    }
  }

  showNotification(title, message) {
    // Simple notification - could be enhanced with a proper notification system
    alert(`${title}: ${message}`)
  }

  async getStorageData(key) {
    return new Promise((resolve) => {
      this.chrome.storage.local.get([key], (result) => {
        resolve(result[key])
      })
    })
  }
}

// Initialize history page when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  new PhishGuardHistory()
})
