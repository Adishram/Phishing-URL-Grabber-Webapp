// PhishGuard Content Script
const chrome = window.chrome // Declare the chrome variable

class PhishGuardContent {
  constructor() {
    this.isInjected = false
    this.currentUrl = window.location.href
    this.init()
  }

  init() {
    this.setupMessageListener()
    this.monitorPageChanges()
    this.injectPageIndicator()
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender, sendResponse)
      return true
    })
  }

  handleMessage(request, sender, sendResponse) {
    switch (request.action) {
      case "getCurrentUrl":
        sendResponse({ url: window.location.href })
        break

      case "showWarning":
        this.showWarningOverlay(request.result)
        sendResponse({ success: true })
        break

      case "hideWarning":
        this.hideWarningOverlay()
        sendResponse({ success: true })
        break

      case "injectIndicator":
        this.injectPageIndicator(request.status)
        sendResponse({ success: true })
        break

      case "scanLinks":
        this.scanPageLinks()
        sendResponse({ success: true })
        break

      default:
        sendResponse({ success: false, error: "Unknown action" })
    }
  }

  monitorPageChanges() {
    // Monitor for URL changes (SPA navigation)
    let lastUrl = window.location.href

    const observer = new MutationObserver(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href
        this.currentUrl = lastUrl
        this.onUrlChange()
      }
    })

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    })

    // Also listen for popstate events
    window.addEventListener("popstate", () => {
      this.onUrlChange()
    })
  }

  onUrlChange() {
    console.log("PhishGuard: URL changed to", this.currentUrl)

    // Remove existing indicators
    this.removePageIndicator()

    // Notify background script of URL change
    chrome.runtime.sendMessage({
      action: "urlChanged",
      url: this.currentUrl,
    })
  }

  injectPageIndicator(status = "unknown") {
    if (this.isInjected) return

    const indicator = document.createElement("div")
    indicator.id = "phishguard-indicator"
    indicator.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            background: rgba(31, 41, 55, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            z-index: 999998;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
        `

    // Set indicator based on status
    switch (status) {
      case "safe":
        indicator.innerHTML = "✅"
        indicator.title = "PhishGuard: This page is safe"
        break
      case "danger":
        indicator.innerHTML = "⚠️"
        indicator.title = "PhishGuard: Potential threat detected"
        indicator.style.background = "rgba(239, 68, 68, 0.9)"
        break
      case "scanning":
        indicator.innerHTML = "🔍"
        indicator.title = "PhishGuard: Scanning page..."
        break
      default:
        indicator.innerHTML = "🛡️"
        indicator.title = "PhishGuard: Click to scan this page"
    }

    // Add click handler
    indicator.addEventListener("click", () => {
      this.requestScan()
    })

    // Add hover effects
    indicator.addEventListener("mouseenter", () => {
      indicator.style.transform = "scale(1.1)"
    })

    indicator.addEventListener("mouseleave", () => {
      indicator.style.transform = "scale(1)"
    })

    document.body.appendChild(indicator)
    this.isInjected = true
  }

  removePageIndicator() {
    const indicator = document.getElementById("phishguard-indicator")
    if (indicator) {
      indicator.remove()
      this.isInjected = false
    }
  }

  updateIndicatorStatus(status) {
    const indicator = document.getElementById("phishguard-indicator")
    if (!indicator) return

    switch (status) {
      case "safe":
        indicator.innerHTML = "✅"
        indicator.title = "PhishGuard: This page is safe"
        indicator.style.background = "rgba(34, 197, 94, 0.9)"
        break
      case "danger":
        indicator.innerHTML = "⚠️"
        indicator.title = "PhishGuard: Potential threat detected"
        indicator.style.background = "rgba(239, 68, 68, 0.9)"
        break
      case "scanning":
        indicator.innerHTML = "🔍"
        indicator.title = "PhishGuard: Scanning page..."
        indicator.style.background = "rgba(99, 102, 241, 0.9)"
        break
    }
  }

  requestScan() {
    this.updateIndicatorStatus("scanning")

    chrome.runtime.sendMessage(
      {
        action: "scanUrl",
        url: this.currentUrl,
      },
      (response) => {
        if (response?.success && response.result) {
          const status = response.result.prediction === "Phishing" ? "danger" : "safe"
          this.updateIndicatorStatus(status)

          if (status === "danger") {
            this.showThreatToast(response.result)
          }
        }
      },
    )
  }

  showThreatToast(result) {
    // Remove existing toast
    const existingToast = document.getElementById("phishguard-toast")
    if (existingToast) existingToast.remove()

    const toast = document.createElement("div")
    toast.id = "phishguard-toast"
    toast.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            background: rgba(239, 68, 68, 0.95);
            color: white;
            padding: 16px 20px;
            border-radius: 12px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
            font-weight: 500;
            z-index: 999997;
            max-width: 300px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideIn 0.3s ease-out;
        `

    toast.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                <span style="font-size: 18px;">⚠️</span>
                <strong>Potential Threat Detected</strong>
            </div>
            <div style="font-size: 12px; opacity: 0.9;">
                Confidence: ${(result.confidence * 100).toFixed(1)}%
            </div>
        `

    // Add CSS animation
    const style = document.createElement("style")
    style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `
    document.head.appendChild(style)

    document.body.appendChild(toast)

    // Auto-remove after 5 seconds
    setTimeout(() => {
      if (toast.parentNode) {
        toast.style.animation = "slideIn 0.3s ease-out reverse"
        setTimeout(() => toast.remove(), 300)
      }
    }, 5000)
  }

  scanPageLinks() {
    const links = document.querySelectorAll("a[href]")
    const suspiciousLinks = []

    links.forEach((link) => {
      const href = link.href
      if (this.isValidUrl(href) && this.isSuspiciousLink(href)) {
        suspiciousLinks.push({
          element: link,
          url: href,
          text: link.textContent.trim(),
        })
      }
    })

    if (suspiciousLinks.length > 0) {
      this.highlightSuspiciousLinks(suspiciousLinks)
    }

    return suspiciousLinks
  }

  isSuspiciousLink(url) {
    const suspiciousPatterns = [
      /bit\.ly|tinyurl|t\.co|goo\.gl/i,
      /[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/,
      /secure.*update|verify.*account|click.*here/i,
      /paypal.*verify|amazon.*update|microsoft.*security/i,
    ]

    return suspiciousPatterns.some((pattern) => pattern.test(url))
  }

  highlightSuspiciousLinks(links) {
    links.forEach(({ element }) => {
      element.style.cssText += `
                border: 2px solid #f59e0b !important;
                background: rgba(245, 158, 11, 0.1) !important;
                border-radius: 4px !important;
                position: relative !important;
            `

      // Add warning icon
      const warning = document.createElement("span")
      warning.innerHTML = "⚠️"
      warning.style.cssText = `
                position: absolute;
                top: -8px;
                right: -8px;
                font-size: 12px;
                background: #f59e0b;
                border-radius: 50%;
                width: 16px;
                height: 16px;
                display: flex;
                align-items: center;
                justify-content: center;
            `

      element.style.position = "relative"
      element.appendChild(warning)
    })
  }

  isValidUrl(url) {
    return url && (url.startsWith("http://") || url.startsWith("https://"))
  }
}

// Initialize content script
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    new PhishGuardContent()
  })
} else {
  new PhishGuardContent()
}
