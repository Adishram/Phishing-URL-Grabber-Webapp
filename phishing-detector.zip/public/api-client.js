// PhishGuard API Client
class PhishGuardAPI {
  constructor() {
    this.baseUrl = "http://127.0.0.1:5000/api"
    this.timeout = 10000 // 10 seconds
  }

  async checkUrl(url) {
    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), this.timeout)

      const response = await fetch(`${this.baseUrl}/check-url`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const result = await response.json()

      // Add client-side metadata
      result.timestamp = new Date().toISOString()
      result.clientVersion = "1.0.0"

      return {
        success: true,
        data: result,
      }
    } catch (error) {
      console.error("API request failed:", error)

      if (error.name === "AbortError") {
        return {
          success: false,
          error: "Request timeout",
          fallback: this.getFallbackResult(url),
        }
      }

      return {
        success: false,
        error: error.message,
        fallback: this.getFallbackResult(url),
      }
    }
  }

  async checkHealth() {
    try {
      const response = await fetch(`${this.baseUrl}/health`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        return {
          success: true,
          data,
          available: true,
        }
      }

      return {
        success: false,
        available: false,
        error: `HTTP ${response.status}`,
      }
    } catch (error) {
      return {
        success: false,
        available: false,
        error: error.message,
      }
    }
  }

  async getStats() {
    try {
      const response = await fetch(`${this.baseUrl}/stats`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        return {
          success: true,
          data,
        }
      }

      return {
        success: false,
        error: `HTTP ${response.status}`,
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
      }
    }
  }

  getFallbackResult(url) {
    // Client-side heuristic analysis as fallback
    const analysis = this.analyzeUrlHeuristics(url)

    return {
      url,
      prediction: analysis.isPhishing ? "Phishing" : "Legitimate",
      confidence: analysis.confidence,
      phishing_probability: analysis.phishingScore,
      legitimate_probability: 1 - analysis.phishingScore,
      timestamp: new Date().toISOString(),
      fallback: true,
      method: "client_heuristics",
    }
  }

  analyzeUrlHeuristics(url) {
    let score = 0
    const factors = []

    try {
      const urlObj = new URL(url)

      // Check for IP address
      if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(urlObj.hostname)) {
        score += 0.3
        factors.push("IP address used")
      }

      // Check URL length
      if (url.length > 100) {
        score += 0.1
        factors.push("Long URL")
      }

      // Check for suspicious keywords
      const suspiciousKeywords = [
        "secure",
        "verify",
        "update",
        "confirm",
        "suspended",
        "click",
        "urgent",
        "immediate",
        "action",
        "required",
      ]

      const foundKeywords = suspiciousKeywords.filter((keyword) => url.toLowerCase().includes(keyword))

      if (foundKeywords.length > 0) {
        score += foundKeywords.length * 0.1
        factors.push(`Suspicious keywords: ${foundKeywords.join(", ")}`)
      }

      // Check for URL shorteners
      const shorteners = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"]
      if (shorteners.some((shortener) => urlObj.hostname.includes(shortener))) {
        score += 0.2
        factors.push("URL shortener detected")
      }

      // Check for suspicious TLDs
      const suspiciousTlds = [".tk", ".ml", ".ga", ".cf"]
      if (suspiciousTlds.some((tld) => urlObj.hostname.endsWith(tld))) {
        score += 0.25
        factors.push("Suspicious TLD")
      }

      // Check for brand impersonation
      const brands = ["paypal", "amazon", "microsoft", "apple", "google"]
      const hostname = urlObj.hostname.toLowerCase()

      for (const brand of brands) {
        if (
          hostname.includes(brand) &&
          !hostname.startsWith(brand + ".") &&
          !hostname.startsWith("www." + brand + ".")
        ) {
          score += 0.3
          factors.push(`Possible ${brand} impersonation`)
          break
        }
      }

      // Check for excessive subdomains
      const subdomains = urlObj.hostname.split(".")
      if (subdomains.length > 4) {
        score += 0.15
        factors.push("Multiple subdomains")
      }

      // Check for HTTPS
      if (urlObj.protocol !== "https:") {
        score += 0.1
        factors.push("Not using HTTPS")
      }

      // Normalize score
      score = Math.min(score, 1.0)

      return {
        isPhishing: score > 0.5,
        phishingScore: score,
        confidence: Math.abs(score - 0.5) * 2, // Convert to confidence
        factors,
      }
    } catch (error) {
      // If URL parsing fails, consider it suspicious
      return {
        isPhishing: true,
        phishingScore: 0.8,
        confidence: 0.6,
        factors: ["Invalid URL format"],
      }
    }
  }

  // Batch URL checking for efficiency
  async checkUrls(urls) {
    const results = []
    const batchSize = 5 // Process 5 URLs at a time

    for (let i = 0; i < urls.length; i += batchSize) {
      const batch = urls.slice(i, i + batchSize)
      const batchPromises = batch.map((url) => this.checkUrl(url))

      try {
        const batchResults = await Promise.allSettled(batchPromises)
        results.push(
          ...batchResults.map((result) =>
            result.status === "fulfilled"
              ? result.value
              : {
                  success: false,
                  error: result.reason?.message || "Unknown error",
                },
          ),
        )
      } catch (error) {
        console.error("Batch processing error:", error)
        // Add fallback results for failed batch
        batch.forEach((url) => {
          results.push({
            success: false,
            error: "Batch processing failed",
            fallback: this.getFallbackResult(url),
          })
        })
      }
    }

    return results
  }

  // Test connection with retry logic
  async testConnection(maxRetries = 3) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      const result = await this.checkHealth()

      if (result.success) {
        return {
          success: true,
          attempt,
          data: result.data,
        }
      }

      if (attempt < maxRetries) {
        // Wait before retry (exponential backoff)
        await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000))
      }
    }

    return {
      success: false,
      attempts: maxRetries,
      error: "Connection failed after all retries",
    }
  }
}

// Export for use in other scripts
if (typeof module !== "undefined" && module.exports) {
  module.exports = PhishGuardAPI
} else if (typeof window !== "undefined") {
  window.PhishGuardAPI = PhishGuardAPI
}
