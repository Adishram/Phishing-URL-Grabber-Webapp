// PhishGuard Settings Page Script
class PhishGuardSettings {
  constructor() {
    this.chrome = window.chrome
    this.settings = {}
    this.init()
  }

  async init() {
    await this.loadSettings()
    this.bindEvents()
    this.updateUI()
    this.checkApiStatus()
  }

  async loadSettings() {
    try {
      const result = await this.getStorageData("settings")
      this.settings = result || {
        autoScan: false,
        realTimeProtection: true,
        blockPhishing: false,
        notifications: true,
        apiEndpoint: "http://127.0.0.1:5000/api",
      }
    } catch (error) {
      console.error("Error loading settings:", error)
      this.settings = {
        autoScan: false,
        realTimeProtection: true,
        blockPhishing: false,
        notifications: true,
        apiEndpoint: "http://127.0.0.1:5000/api",
      }
    }
  }

  updateUI() {
    // Update toggle switches
    document.getElementById("autoScan").checked = this.settings.autoScan
    document.getElementById("realTimeProtection").checked = this.settings.realTimeProtection
    document.getElementById("blockPhishing").checked = this.settings.blockPhishing
    document.getElementById("notifications").checked = this.settings.notifications

    // Update API endpoint
    document.getElementById("apiEndpoint").value = this.settings.apiEndpoint || "http://127.0.0.1:5000/api"
  }

  bindEvents() {
    // Toggle switches
    document.getElementById("autoScan").addEventListener("change", (e) => {
      this.updateSetting("autoScan", e.target.checked)
    })

    document.getElementById("realTimeProtection").addEventListener("change", (e) => {
      this.updateSetting("realTimeProtection", e.target.checked)
    })

    document.getElementById("blockPhishing").addEventListener("change", (e) => {
      this.updateSetting("blockPhishing", e.target.checked)
    })

    document.getElementById("notifications").addEventListener("change", (e) => {
      this.updateSetting("notifications", e.target.checked)
    })

    // API endpoint
    document.getElementById("apiEndpoint").addEventListener("blur", (e) => {
      this.updateSetting("apiEndpoint", e.target.value)
    })

    // Buttons
    document.getElementById("testConnection").addEventListener("click", () => {
      this.testApiConnection()
    })

    document.getElementById("exportData").addEventListener("click", () => {
      this.exportData()
    })

    document.getElementById("clearAllData").addEventListener("click", () => {
      this.clearAllData()
    })

    document.getElementById("openSupport").addEventListener("click", () => {
      this.openSupport()
    })
  }

  async updateSetting(key, value) {
    this.settings[key] = value

    try {
      await this.chrome.storage.local.set({ settings: this.settings })

      // Send message to background script about settings change
      this.chrome.runtime.sendMessage({
        action: "updateSettings",
        settings: this.settings,
      })

      this.showNotification("Settings updated", `${key} has been ${value ? "enabled" : "disabled"}`)
    } catch (error) {
      console.error("Error updating settings:", error)
      this.showNotification("Error", "Failed to update settings")
    }
  }

  async checkApiStatus() {
    const statusIndicator = document.getElementById("apiStatus")
    statusIndicator.innerHTML = "<span>🔄</span><span>Checking...</span>"

    try {
      const endpoint = this.settings.apiEndpoint || "http://127.0.0.1:5000/api"
      const response = await fetch(`${endpoint}/health`, {
        method: "GET",
        timeout: 5000,
      })

      if (response.ok) {
        const data = await response.json()
        statusIndicator.className = "status-indicator online"
        statusIndicator.innerHTML = "<span>✅</span><span>Online</span>"
      } else {
        throw new Error(`HTTP ${response.status}`)
      }
    } catch (error) {
      statusIndicator.className = "status-indicator offline"
      statusIndicator.innerHTML = "<span>❌</span><span>Offline</span>"
    }
  }

  async testApiConnection() {
    const button = document.getElementById("testConnection")
    const originalText = button.textContent

    button.textContent = "Testing..."
    button.disabled = true

    try {
      const endpoint = document.getElementById("apiEndpoint").value
      const response = await fetch(`${endpoint}/health`, {
        method: "GET",
        timeout: 10000,
      })

      if (response.ok) {
        const data = await response.json()
        this.showNotification("Connection successful", `API is responding. Status: ${data.status}`)
        this.updateSetting("apiEndpoint", endpoint)
        this.checkApiStatus()
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }
    } catch (error) {
      this.showNotification("Connection failed", `Unable to connect to API: ${error.message}`)
    } finally {
      button.textContent = originalText
      button.disabled = false
    }
  }

  async exportData() {
    try {
      const history = (await this.getStorageData("scanHistory")) || []
      const settings = (await this.getStorageData("settings")) || {}
      const stats = (await this.getStorageData("stats")) || {}

      const exportData = {
        exportDate: new Date().toISOString(),
        version: "1.0.0",
        settings,
        stats,
        history,
        summary: {
          totalScans: history.length,
          safeUrls: history.filter((scan) => scan.prediction === "Legitimate").length,
          threatsDetected: history.filter((scan) => scan.prediction === "Phishing").length,
        },
      }

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: "application/json",
      })

      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `phishguard-export-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      this.showNotification("Export successful", "Your data has been exported successfully")
    } catch (error) {
      console.error("Export error:", error)
      this.showNotification("Export failed", "Failed to export data")
    }
  }

  async clearAllData() {
    const confirmed = confirm(
      "Are you sure you want to clear all data?\n\n" +
        "This will remove:\n" +
        "• All scan history\n" +
        "• All statistics\n" +
        "• All settings (reset to defaults)\n\n" +
        "This action cannot be undone.",
    )

    if (!confirmed) return

    try {
      // Clear all stored data
      await this.chrome.storage.local.clear()

      // Reset to default settings
      const defaultSettings = {
        autoScan: false,
        realTimeProtection: true,
        blockPhishing: false,
        notifications: true,
        apiEndpoint: "http://127.0.0.1:5000/api",
      }

      await this.chrome.storage.local.set({
        settings: defaultSettings,
        scanHistory: [],
        stats: {
          totalScans: 0,
          threatsBlocked: 0,
          safeUrls: 0,
        },
      })

      this.settings = defaultSettings
      this.updateUI()

      this.showNotification("Data cleared", "All data has been cleared and settings reset to defaults")
    } catch (error) {
      console.error("Clear data error:", error)
      this.showNotification("Clear failed", "Failed to clear data")
    }
  }

  openSupport() {
    // In a real extension, this would open a support page or email
    const supportInfo = `
PhishGuard Support Information:

Version: 1.0.0
User Agent: ${navigator.userAgent}
Extension ID: ${this.chrome.runtime.id}

For support, please contact:
- Email: support@phishguard.example
- GitHub: https://github.com/phishguard/extension

Common Issues:
1. API Connection Failed: Make sure your Flask server is running on the correct port
2. Scans Not Working: Check that the API endpoint is correctly configured
3. Extension Not Loading: Try disabling and re-enabling the extension

Debug Information:
- Settings: ${JSON.stringify(this.settings, null, 2)}
        `

    // Create a modal or new tab with support information
    const newTab = window.open("", "_blank")
    newTab.document.write(`
            <html>
                <head>
                    <title>PhishGuard Support</title>
                    <style>
                        body { 
                            font-family: monospace; 
                            padding: 20px; 
                            background: #1f2937; 
                            color: #f8fafc; 
                        }
                        pre { 
                            white-space: pre-wrap; 
                            background: rgba(255,255,255,0.1); 
                            padding: 20px; 
                            border-radius: 8px; 
                        }
                    </style>
                </head>
                <body>
                    <h1>PhishGuard Support</h1>
                    <pre>${supportInfo}</pre>
                </body>
            </html>
        `)
  }

  showNotification(title, message) {
    // Simple notification - could be enhanced with a proper notification system
    if (this.settings.notifications) {
      this.chrome.notifications.create({
        type: "basic",
        iconUrl: "icon48.png",
        title,
        message,
      })
    }

    // Also show browser alert as fallback
    console.log(`${title}: ${message}`)
  }

  async getStorageData(key) {
    return new Promise((resolve) => {
      this.chrome.storage.local.get([key], (result) => {
        resolve(result[key])
      })
    })
  }
}

// Initialize settings page when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  new PhishGuardSettings()
})
