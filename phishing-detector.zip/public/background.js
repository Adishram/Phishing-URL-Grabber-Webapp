// PhishGuard Background Service Worker
const chrome = window.chrome // Declare the chrome variable

class PhishGuardAPI {
  async checkUrl(url) {
    const response = await fetch("http://127.0.0.1:5000/api/check-url", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ url }),
    })

    if (!response.ok) {
      return { success: false, error: `API request failed: ${response.status}` }
    }

    const data = await response.json()
    return { success: true, data }
  }

  async checkHealth() {
    const response = await fetch("http://127.0.0.1:5000/api/health")

    if (!response.ok) {
      return { success: false, error: `API request failed: ${response.status}` }
    }

    const data = await response.json()
    return { success: true, data }
  }
}

class PhishGuardBackground {
  constructor() {
    this.api = new PhishGuardAPI() // Use the new API client
    this.init()
  }

  init() {
    this.setupEventListeners()
    this.setupContextMenus()
    this.checkApiHealth()
  }

  setupEventListeners() {
    // Handle extension installation
    chrome.runtime.onInstalled.addListener((details) => {
      if (details.reason === "install") {
        this.onInstall()
      } else if (details.reason === "update") {
        this.onUpdate()
      }
    })

    // Handle tab updates for real-time protection
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      if (changeInfo.status === "complete" && tab.url) {
        this.handleTabUpdate(tabId, tab)
      }
    })

    // Handle messages from content scripts and popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender, sendResponse)
      return true // Keep message channel open for async response
    })

    // Handle context menu clicks
    chrome.contextMenus.onClicked.addListener((info, tab) => {
      this.handleContextMenuClick(info, tab)
    })
  }

  setupContextMenus() {
    chrome.contextMenus.create({
      id: "scanCurrentPage",
      title: "Scan this page with PhishGuard",
      contexts: ["page"],
    })

    chrome.contextMenus.create({
      id: "scanLink",
      title: "Scan this link with PhishGuard",
      contexts: ["link"],
    })
  }

  async onInstall() {
    console.log("PhishGuard installed")

    // Initialize storage
    await chrome.storage.local.set({
      scanHistory: [],
      settings: {
        autoScan: false,
        realTimeProtection: true,
        notifications: true,
        blockPhishing: false,
      },
      stats: {
        totalScans: 0,
        threatsBlocked: 0,
        safeUrls: 0,
      },
    })

    // Show welcome notification
    this.showNotification("PhishGuard Installed", "Your advanced phishing protection is now active!", "welcome")
  }

  async onUpdate() {
    console.log("PhishGuard updated")
    this.showNotification("PhishGuard Updated", "New features and improvements are now available!", "update")
  }

  async handleTabUpdate(tabId, tab) {
    const settings = await this.getStorageData("settings")

    if (settings?.autoScan && this.isValidUrl(tab.url)) {
      // Auto-scan the page if enabled
      setTimeout(() => {
        this.scanUrl(tab.url, tabId)
      }, 2000) // Wait 2 seconds for page to load
    }
  }

  async handleMessage(request, sender, sendResponse) {
    try {
      switch (request.action) {
        case "scanUrl":
          const result = await this.scanUrl(request.url, sender.tab?.id)
          sendResponse({ success: true, result })
          break

        case "getStats":
          const stats = await this.getStats()
          sendResponse({ success: true, stats })
          break

        case "updateSettings":
          await this.updateSettings(request.settings)
          sendResponse({ success: true })
          break

        case "clearHistory":
          await this.clearHistory()
          sendResponse({ success: true })
          break

        case "exportData":
          const data = await this.exportData()
          sendResponse({ success: true, data })
          break

        default:
          sendResponse({ success: false, error: "Unknown action" })
      }
    } catch (error) {
      console.error("Background script error:", error)
      sendResponse({ success: false, error: error.message })
    }
  }

  async handleContextMenuClick(info, tab) {
    let urlToScan = ""

    if (info.menuItemId === "scanCurrentPage") {
      urlToScan = tab.url
    } else if (info.menuItemId === "scanLink") {
      urlToScan = info.linkUrl
    }

    if (urlToScan && this.isValidUrl(urlToScan)) {
      await this.scanUrl(urlToScan, tab.id)
    }
  }

  async scanUrl(url, tabId = null) {
    try {
      console.log("Scanning URL:", url)

      const response = await this.api.checkUrl(url)
      let result

      if (response.success) {
        result = response.data
      } else {
        // Use fallback result if API fails
        result = response.fallback || this.createErrorResult(url, response.error)
      }

      result.tabId = tabId

      // Save to history
      await this.saveToHistory(result)

      // Update stats
      await this.updateStats(result)

      // Handle real-time protection
      await this.handleRealTimeProtection(result, tabId)

      // Show notification if threat detected
      if (result.prediction === "Phishing") {
        this.showThreatNotification(result)
      }

      return result
    } catch (error) {
      console.error("Scan error:", error)

      const errorResult = this.createErrorResult(url, error.message)
      await this.saveToHistory(errorResult)
      return errorResult
    }
  }

  createErrorResult(url, errorMessage) {
    return {
      url,
      prediction: "Unknown",
      confidence: 0,
      phishing_probability: 0,
      legitimate_probability: 0,
      timestamp: new Date().toISOString(),
      error: errorMessage,
      fallback: true,
    }
  }

  async handleRealTimeProtection(result, tabId) {
    const settings = await this.getStorageData("settings")

    if (settings?.realTimeProtection && result.prediction === "Phishing" && tabId) {
      if (settings.blockPhishing) {
        // Block the page
        chrome.tabs.update(tabId, {
          url: chrome.runtime.getURL("blocked.html") + "?url=" + encodeURIComponent(result.url),
        })
      } else {
        // Inject warning overlay
        chrome.scripting.executeScript({
          target: { tabId },
          func: this.injectWarningOverlay,
          args: [result],
        })
      }
    }
  }

  injectWarningOverlay(result) {
    // This function runs in the content script context
    if (document.getElementById("phishguard-warning")) return

    const overlay = document.createElement("div")
    overlay.id = "phishguard-warning"
    overlay.innerHTML = `
            <div style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.9);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            ">
                <div style="
                    background: #1f2937;
                    color: #f8fafc;
                    padding: 40px;
                    border-radius: 16px;
                    max-width: 500px;
                    text-align: center;
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
                ">
                    <div style="font-size: 48px; margin-bottom: 20px;">⚠️</div>
                    <h2 style="color: #ef4444; margin-bottom: 16px; font-size: 24px;">Potential Phishing Site Detected</h2>
                    <p style="margin-bottom: 20px; color: #d1d5db;">
                        PhishGuard has detected that this website may be attempting to steal your personal information.
                    </p>
                    <p style="margin-bottom: 30px; font-size: 14px; color: #9ca3af;">
                        Confidence: ${(result.confidence * 100).toFixed(1)}%
                    </p>
                    <div style="display: flex; gap: 12px; justify-content: center;">
                        <button onclick="history.back()" style="
                            background: #ef4444;
                            color: white;
                            border: none;
                            padding: 12px 24px;
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                        ">Go Back</button>
                        <button onclick="document.getElementById('phishguard-warning').remove()" style="
                            background: #6b7280;
                            color: white;
                            border: none;
                            padding: 12px 24px;
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                        ">Continue Anyway</button>
                    </div>
                </div>
            </div>
        `

    document.body.appendChild(overlay)
  }

  async saveToHistory(result) {
    const history = (await this.getStorageData("scanHistory")) || []
    history.unshift(result)

    // Keep only last 1000 scans
    if (history.length > 1000) {
      history.splice(1000)
    }

    await chrome.storage.local.set({ scanHistory: history })
  }

  async updateStats(result) {
    const stats = (await this.getStorageData("stats")) || {
      totalScans: 0,
      threatsBlocked: 0,
      safeUrls: 0,
    }

    stats.totalScans++

    if (result.prediction === "Phishing") {
      stats.threatsBlocked++
    } else if (result.prediction === "Legitimate") {
      stats.safeUrls++
    }

    await chrome.storage.local.set({ stats })
  }

  async getStats() {
    const history = (await this.getStorageData("scanHistory")) || []
    const stats = (await this.getStorageData("stats")) || {}

    const today = new Date().toDateString()
    const todayScans = history.filter((scan) => new Date(scan.timestamp).toDateString() === today).length

    return {
      ...stats,
      todayScans,
      totalScans: history.length,
    }
  }

  async updateSettings(newSettings) {
    const currentSettings = (await this.getStorageData("settings")) || {}
    const updatedSettings = { ...currentSettings, ...newSettings }
    await chrome.storage.local.set({ settings: updatedSettings })
  }

  async clearHistory() {
    await chrome.storage.local.set({ scanHistory: [] })
  }

  async exportData() {
    const history = (await this.getStorageData("scanHistory")) || []
    const settings = (await this.getStorageData("settings")) || {}
    const stats = (await this.getStorageData("stats")) || {}

    return {
      history,
      settings,
      stats,
      exportDate: new Date().toISOString(),
      version: "1.0.0",
    }
  }

  showNotification(title, message, type = "info") {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon48.png",
      title,
      message,
    })
  }

  showThreatNotification(result) {
    const settings = this.getStorageData("settings")
    if (settings?.notifications === false) return

    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon48.png",
      title: "Phishing Threat Detected",
      message: `Potentially dangerous site detected with ${(result.confidence * 100).toFixed(1)}% confidence.`,
    })
  }

  async checkApiHealth() {
    const healthCheck = await this.api.checkHealth()
    if (healthCheck.success) {
      console.log("PhishGuard API is healthy:", healthCheck.data)
    } else {
      console.warn("PhishGuard API not available:", healthCheck.error)
    }
  }

  isValidUrl(url) {
    return (
      url &&
      (url.startsWith("http://") || url.startsWith("https://")) &&
      !url.startsWith("chrome://") &&
      !url.startsWith("chrome-extension://")
    )
  }

  async getStorageData(key) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => {
        resolve(result[key])
      })
    })
  }
}

// Load API client and initialize background service
const script = document.createElement("script")
script.src = "api-client.js"
script.onload = () => {
  new PhishGuardBackground()
}
document.head.appendChild(script)
