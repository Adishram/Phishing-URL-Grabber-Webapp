// PhishGuard Popup Script
class PhishGuardPopup {
  constructor() {
    this.currentUrl = ""
    this.isScanning = false
    this.chrome = window.chrome // Declare the chrome variable
    this.api = new window.PhishGuardAPI() // Use the new API client
    this.init()
  }

  async init() {
    await this.loadCurrentUrl()
    await this.checkApiConnection()
    this.loadStats()
    this.bindEvents()
  }

  async loadCurrentUrl() {
    try {
      const [tab] = await this.chrome.tabs.query({ active: true, currentWindow: true })
      this.currentUrl = tab.url
      document.getElementById("currentUrl").textContent = this.formatUrl(this.currentUrl)
    } catch (error) {
      console.error("Error loading current URL:", error)
      document.getElementById("currentUrl").textContent = "Unable to load current page"
    }
  }

  formatUrl(url) {
    if (url.length > 50) {
      return url.substring(0, 47) + "..."
    }
    return url
  }

  bindEvents() {
    document.getElementById("scanButton").addEventListener("click", () => this.scanCurrentPage())
    document.getElementById("historyButton").addEventListener("click", () => this.openHistory())
    document.getElementById("settingsButton").addEventListener("click", () => this.openSettings())
  }

  async scanCurrentPage() {
    if (this.isScanning || !this.currentUrl) return

    this.setScanning(true)
    this.hideResult()

    try {
      const result = await this.scanUrl(this.currentUrl)
      this.displayResult(result)
      await this.saveToHistory(result)
      this.updateStats()
    } catch (error) {
      console.error("Scan error:", error)
      this.displayError("Failed to scan URL. Please check your connection.")
    } finally {
      this.setScanning(false)
    }
  }

  async scanUrl(url) {
    const response = await this.api.checkUrl(url)

    if (response.success) {
      return response.data
    } else {
      // Use fallback result if API fails
      if (response.fallback) {
        return response.fallback
      }
      throw new Error(response.error)
    }
  }

  setScanning(scanning) {
    this.isScanning = scanning
    const button = document.getElementById("scanButton")
    const icon = document.getElementById("scanIcon")
    const text = document.getElementById("scanText")

    if (scanning) {
      button.disabled = true
      icon.innerHTML = '<div class="loading"></div>'
      text.textContent = "Scanning..."
    } else {
      button.disabled = false
      icon.textContent = "🔍"
      text.textContent = "Scan Current Page"
    }
  }

  displayResult(result) {
    const resultDiv = document.getElementById("scanResult")
    const resultIcon = document.getElementById("resultIcon")
    const resultTitle = document.getElementById("resultTitle")
    const confidence = document.getElementById("confidence")
    const riskLevel = document.getElementById("riskLevel")

    const isPhishing = result.prediction === "Phishing"
    const riskScore = result.phishing_probability

    // Set result styling
    resultDiv.className = `result ${isPhishing ? "danger" : "safe"}`
    resultIcon.className = `result-icon ${isPhishing ? "danger" : "safe"}`
    resultIcon.textContent = isPhishing ? "⚠️" : "✅"

    // Set content
    resultTitle.textContent = isPhishing ? "Potential Threat Detected" : "Safe URL"
    confidence.textContent = `${(result.confidence * 100).toFixed(1)}%`

    let riskText = "Low"
    let riskColor = "#22c55e"
    if (riskScore > 0.7) {
      riskText = "High"
      riskColor = "#ef4444"
    } else if (riskScore > 0.3) {
      riskText = "Medium"
      riskColor = "#f59e0b"
    }

    riskLevel.textContent = riskText
    riskLevel.style.color = riskColor

    resultDiv.classList.remove("hidden")
  }

  displayError(message) {
    const resultDiv = document.getElementById("scanResult")
    const resultIcon = document.getElementById("resultIcon")
    const resultTitle = document.getElementById("resultTitle")
    const confidence = document.getElementById("confidence")
    const riskLevel = document.getElementById("riskLevel")

    resultDiv.className = "result danger"
    resultIcon.className = "result-icon danger"
    resultIcon.textContent = "❌"
    resultTitle.textContent = "Scan Failed"
    confidence.textContent = "N/A"
    riskLevel.textContent = message

    resultDiv.classList.remove("hidden")
  }

  hideResult() {
    document.getElementById("scanResult").classList.add("hidden")
  }

  async saveToHistory(result) {
    try {
      const history = (await this.getStorageData("scanHistory")) || []
      history.unshift(result)

      // Keep only last 100 scans
      if (history.length > 100) {
        history.splice(100)
      }

      await this.chrome.storage.local.set({ scanHistory: history })
    } catch (error) {
      console.error("Error saving to history:", error)
    }
  }

  async loadStats() {
    try {
      const history = (await this.getStorageData("scanHistory")) || []
      const today = new Date().toDateString()

      const todayScans = history.filter((scan) => new Date(scan.timestamp).toDateString() === today).length

      const totalScans = history.length
      const threatsBlocked = history.filter((scan) => scan.prediction === "Phishing").length
      const safeUrls = history.filter((scan) => scan.prediction === "Legitimate").length

      document.getElementById("todayScans").textContent = todayScans
      document.getElementById("totalScans").textContent = totalScans
      document.getElementById("threatsBlocked").textContent = threatsBlocked
      document.getElementById("safeUrls").textContent = safeUrls
    } catch (error) {
      console.error("Error loading stats:", error)
    }
  }

  async updateStats() {
    await this.loadStats()
  }

  async getStorageData(key) {
    return new Promise((resolve) => {
      this.chrome.storage.local.get([key], (result) => {
        resolve(result[key])
      })
    })
  }

  openHistory() {
    this.chrome.tabs.create({ url: this.chrome.runtime.getURL("history.html") })
    window.close()
  }

  openSettings() {
    this.chrome.tabs.create({ url: this.chrome.runtime.getURL("settings.html") })
    window.close()
  }

  async checkApiConnection() {
    const connectionTest = await this.api.testConnection(2)
    if (!connectionTest.success) {
      this.showApiError()
    }
  }

  showApiError() {
    const errorDiv = document.createElement("div")
    errorDiv.style.cssText = `
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 16px;
      font-size: 12px;
      color: #ef4444;
      text-align: center;
    `
    errorDiv.innerHTML = `
      ⚠️ API Connection Failed<br>
      <span style="font-size: 10px; opacity: 0.8;">
        Make sure your Flask server is running on port 5000
      </span>
    `

    const content = document.querySelector(".content")
    content.insertBefore(errorDiv, content.firstChild)
  }
}

// Load API client script
const script = document.createElement("script")
script.src = "api-client.js"
document.head.appendChild(script)

// Initialize popup when both DOM and API client are loaded
let apiClientLoaded = false
let domLoaded = false

script.onload = () => {
  apiClientLoaded = true
  if (domLoaded) {
    new PhishGuardPopup()
  }
}

document.addEventListener("DOMContentLoaded", () => {
  domLoaded = true
  if (apiClientLoaded) {
    new PhishGuardPopup()
  }
})
